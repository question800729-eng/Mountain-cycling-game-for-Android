// ============================================================
//  MOUNTAIN CYCLE RUSH - Full Game Engine
//  50 Levels | 10 Bikes | 2 Maps | Physics Engine
// ============================================================

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// ── Resize Canvas ──────────────────────────────────────────
function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener('resize', () => { resizeCanvas(); if (gameState === 'playing') drawGame(); });
resizeCanvas();

// ── Game State ─────────────────────────────────────────────
let gameState = 'menu'; // menu | playing | paused | win | lose
let currentMap = 1;
let currentLevel = 1;
let selectedBike = 0;
let score = 0;
let gameTime = 0;
let gameTimerInterval = null;
let fuel = 100;
let frameId = null;
let isGameRunning = false;

// ── Save Data ──────────────────────────────────────────────
let saveData = {
  unlockedLevels: { 1: [1], 2: [] },
  completedLevels: {},
  levelStars: {},
  unlockedBikes: [0, 1, 2],
  selectedBike: 0,
  coins: 0
};
function loadSave() {
  try {
    const s = localStorage.getItem('mcr_save');
    if (s) saveData = JSON.parse(s);
    // ensure defaults
    if (!saveData.unlockedLevels) saveData.unlockedLevels = { 1: [1], 2: [] };
    if (!saveData.completedLevels) saveData.completedLevels = {};
    if (!saveData.levelStars) saveData.levelStars = {};
    if (!saveData.unlockedBikes) saveData.unlockedBikes = [0,1,2];
    selectedBike = saveData.selectedBike || 0;
  } catch(e) {}
}
function saveSave() {
  saveData.selectedBike = selectedBike;
  localStorage.setItem('mcr_save', JSON.stringify(saveData));
}

// ── BIKES DATA ─────────────────────────────────────────────
const BIKES = [
  { id:0, name:'Trail Blazer', emoji:'🚵', color:'#4fc3f7', speed:3.5, accel:0.18, grip:0.85, fuel_use:0.08, weight:1.0, stars:'⭐⭐', unlock:0 },
  { id:1, name:'Dirt Rider',   emoji:'🏍️', color:'#ff7043', speed:4.2, accel:0.22, grip:0.78, fuel_use:0.10, weight:0.9, stars:'⭐⭐', unlock:0 },
  { id:2, name:'Mountain X',  emoji:'🛵', color:'#66bb6a', speed:3.8, accel:0.20, grip:0.90, fuel_use:0.07, weight:1.1, stars:'⭐⭐⭐', unlock:0 },
  { id:3, name:'Speed King',  emoji:'🏎️', color:'#ffd700', speed:5.5, accel:0.30, grip:0.70, fuel_use:0.14, weight:0.8, stars:'⭐⭐⭐', unlock:5 },
  { id:4, name:'Rock Crusher', emoji:'🚜', color:'#8d6e63', speed:3.0, accel:0.15, grip:0.95, fuel_use:0.06, weight:1.4, stars:'⭐⭐⭐', unlock:8 },
  { id:5, name:'Volcano Beast',emoji:'🔥', color:'#ef5350', speed:4.8, accel:0.28, grip:0.75, fuel_use:0.13, weight:0.95, stars:'⭐⭐⭐⭐', unlock:12 },
  { id:6, name:'Ghost Rider',  emoji:'💀', color:'#ab47bc', speed:5.0, accel:0.32, grip:0.72, fuel_use:0.12, weight:0.85, stars:'⭐⭐⭐⭐', unlock:15 },
  { id:7, name:'Thunder Fox',  emoji:'⚡', color:'#26c6da', speed:5.8, accel:0.35, grip:0.68, fuel_use:0.16, weight:0.78, stars:'⭐⭐⭐⭐⭐', unlock:20 },
  { id:8, name:'Iron Titan',   emoji:'🤖', color:'#78909c', speed:3.2, accel:0.14, grip:1.00, fuel_use:0.05, weight:1.6, stars:'⭐⭐⭐⭐', unlock:25 },
  { id:9, name:'Ninja Storm',  emoji:'🥷', color:'#1a237e', speed:6.5, accel:0.40, grip:0.65, fuel_use:0.18, weight:0.75, stars:'⭐⭐⭐⭐⭐', unlock:30 }
];

// ── LEVEL GENERATOR ────────────────────────────────────────
function generateLevel(mapId, levelNum) {
  const isVolcano = mapId === 2;
  const difficulty = levelNum; // 1-25 within map
  const W = 5000 + levelNum * 200; // track width grows per level

  // Terrain generation
  const points = [];
  const seg = 60;
  const numPoints = Math.floor(W / seg);
  let y = canvas.height * 0.55;
  let prevSlope = 0;

  // Difficulty factors
  const slopeMax = 0.8 + difficulty * 0.04;
  const bumpiness = 0.3 + difficulty * 0.03;
  const obstacleFreq = Math.min(0.35, 0.05 + difficulty * 0.012);

  for (let i = 0; i < numPoints; i++) {
    const t = i / numPoints;
    // Base wave
    let dy = Math.sin(i * 0.15 + difficulty) * seg * bumpiness;
    // Steeper hills at higher difficulty
    if (Math.random() < 0.15 + difficulty*0.01) dy += (Math.random()-0.5) * seg * slopeMax * 2;
    // Clamp slope
    dy = Math.max(-seg * slopeMax, Math.min(seg * slopeMax, dy));
    // Smoothing
    dy = dy * 0.4 + prevSlope * 0.6;
    prevSlope = dy;
    y += dy;
    // Keep in bounds
    y = Math.max(canvas.height * 0.3, Math.min(canvas.height * 0.82, y));
    points.push({ x: i * seg, y: y });
  }
  // Start flat
  for (let i = 0; i < 5; i++) points[i].y = canvas.height * 0.6;
  // End: finish line area flat
  for (let i = numPoints - 4; i < numPoints; i++) {
    points[i].y = points[numPoints - 5].y;
  }

  // Obstacles
  const obstacles = [];
  for (let i = 8; i < numPoints - 6; i++) {
    if (Math.random() < obstacleFreq) {
      const type = pickObstacleType(difficulty, isVolcano);
      const px = points[i].x + (Math.random() - 0.5) * 20;
      const py = points[i].y;
      const terrainAngle = Math.atan2(points[i].y - points[Math.max(0,i-1)].y, seg);
      obstacles.push({ type, x: px, y: py, angle: terrainAngle, id: i });
      i += 3 + Math.floor(Math.random() * 3); // spacing
    }
  }

  // Collectibles (coins/stars)
  const collectibles = [];
  for (let i = 5; i < numPoints - 5; i += 4 + Math.floor(Math.random()*3)) {
    if (Math.random() < 0.5) {
      collectibles.push({
        x: points[i].x + (Math.random()-0.5)*30,
        y: points[i].y - 40 - Math.random()*40,
        type: Math.random() < 0.15 ? 'star' : 'coin',
        collected: false, id: i + '_c'
      });
    }
  }

  // Fuel cans every ~400px
  const fuelCans = [];
  for (let i = 10; i < numPoints - 10; i += Math.floor(400/seg)) {
    fuelCans.push({ x: points[i].x, y: points[i].y - 35, collected: false });
  }

  return {
    width: W,
    points,
    obstacles,
    collectibles,
    fuelCans,
    finishX: points[numPoints - 3].x,
    finishY: points[numPoints - 3].y,
    mapId,
    levelNum,
    difficulty,
    seg,
    timeLimit: 120 + (25 - difficulty) * 5, // seconds
    isVolcano
  };
}

function pickObstacleType(diff, isVolcano) {
  const pool = ['rock', 'mud'];
  if (diff >= 3) pool.push('hole', 'rock');
  if (diff >= 6) pool.push('log', 'mud', 'hole');
  if (diff >= 10) pool.push('spike', 'bigrock', 'mud');
  if (diff >= 15) pool.push('lavapool', 'boulder', 'deephole');
  if (diff >= 20) pool.push('gap', 'spike', 'boulder');
  if (isVolcano) { pool.push('lavapool', 'lavapool', 'spike'); }
  return pool[Math.floor(Math.random() * pool.length)];
}

// ── PHYSICS ENGINE ─────────────────────────────────────────
let bike = {};
let level = null;
let camera = { x: 0 };
let particles = [];
let inputState = { gas: false, brake: false, leanFwd: false, leanBack: false };

function initBike(bikeId, levelData) {
  const bd = BIKES[bikeId];
  const startY = levelData.points[3].y;
  bike = {
    x: levelData.points[3].x,
    y: startY - 50,
    vx: 0, vy: 0,
    angle: 0, angularVel: 0,
    onGround: false,
    groundAngle: 0,
    wheelRadius: 18,
    data: bd,
    flip: false,
    crashTimer: 0,
    crashed: false,
    wobble: 0,
    trailPoints: [],
    mudSlow: 0,
    airTime: 0
  };
}

function getTerrainY(x, lvl) {
  const pts = lvl.points;
  const seg = lvl.seg;
  const idx = Math.floor(x / seg);
  if (idx < 0) return pts[0].y;
  if (idx >= pts.length - 1) return pts[pts.length - 1].y;
  const t = (x - pts[idx].x) / seg;
  return pts[idx].y + (pts[idx + 1].y - pts[idx].y) * t;
}

function getTerrainAngle(x, lvl) {
  const y1 = getTerrainY(x - 5, lvl);
  const y2 = getTerrainY(x + 5, lvl);
  return Math.atan2(y2 - y1, 10);
}

function updateBike(dt) {
  if (!level || bike.crashed) return;
  const bd = bike.data;
  const terrainY = getTerrainY(bike.x, level);
  const terrainAngle = getTerrainAngle(bike.x, level);
  const bikeBottom = bike.y + bike.wheelRadius;
  const groundContact = bikeBottom >= terrainY - 2;

  // Gravity
  bike.vy += 0.45 * dt;

  // Obstacle interaction
  let onMud = false;
  let hitObstacle = false;
  for (const obs of level.obstacles) {
    const dx = bike.x - obs.x;
    const dy = bike.y - obs.y;
    const dist = Math.sqrt(dx*dx + dy*dy);

    switch(obs.type) {
      case 'mud':
        if (Math.abs(dx) < 35 && dy > -20 && dy < 40) { onMud = true; bike.mudSlow = 30; }
        break;
      case 'hole': case 'deephole':
        if (Math.abs(dx) < 20 && dy > -5 && dy < 35 && groundContact) {
          bike.vy += 3; bike.angularVel += (Math.random()-0.5)*0.3;
          if (obs.type === 'deephole') { bike.crashed = true; showLose('Fell in a deep hole!'); return; }
        }
        break;
      case 'rock': case 'bigrock':
        const rSize = obs.type === 'bigrock' ? 28 : 18;
        if (dist < rSize + bike.wheelRadius * 0.8) {
          if (Math.abs(bike.vx) > 2.5 || Math.abs(bike.vy) > 3) {
            bike.crashed = true; showLose('Hit a rock!'); return;
          }
          bike.vx *= 0.4; bike.vy = -1;
        }
        break;
      case 'log':
        if (Math.abs(dx) < 22 && dy > -25 && dy < 30) {
          if (Math.abs(bike.vx) > 3) { bike.crashed = true; showLose('Hit a log!'); return; }
          bike.vx *= 0.5; bike.vy = -2;
        }
        break;
      case 'spike':
        if (dist < 20) { bike.crashed = true; showLose('Hit a spike!'); return; }
        break;
      case 'lavapool':
        if (Math.abs(dx) < 40 && dy > -15 && dy < 35) { bike.crashed = true; showLose('Burned in lava!'); return; }
        break;
      case 'boulder':
        if (dist < 35 + bike.wheelRadius) { bike.crashed = true; showLose('Crushed by boulder!'); return; }
        break;
      case 'gap':
        if (Math.abs(dx) < 45 && dy > 10 && dy < 60 && !groundContact) {
          // Fall through gap
        }
        break;
    }
  }

  // Ground physics
  if (groundContact) {
    bike.airTime = 0;
    bike.y = terrainY - bike.wheelRadius;
    bike.vy *= -0.15;
    if (bike.vy > 0) bike.vy = 0;
    bike.onGround = true;
    bike.groundAngle = terrainAngle;

    // Friction & control
    let friction = 0.88;
    if (onMud || bike.mudSlow > 0) { friction = 0.72; bike.mudSlow--; }

    // Gas
    if (inputState.gas && fuel > 0) {
      const force = bd.accel * (bike.mudSlow > 0 ? 0.4 : 1.0) * dt;
      bike.vx += Math.cos(terrainAngle) * force * 12;
      bike.vy += Math.sin(terrainAngle) * force * 12;
      fuel = Math.max(0, fuel - bd.fuel_use * dt * 0.6);
      if (fuel <= 0) { bike.crashed = true; showLose('Out of fuel!'); return; }
    }
    // Brake
    if (inputState.brake) {
      bike.vx *= 0.82;
    }
    // Speed cap
    const maxSpd = bd.speed * (onMud ? 0.4 : 1.0);
    if (bike.vx > maxSpd) bike.vx = maxSpd;
    if (bike.vx < -maxSpd * 0.5) bike.vx = -maxSpd * 0.5;

    bike.vx *= friction;
    // Slope gravity component
    bike.vx += Math.sin(terrainAngle) * (-0.25 * dt);

    // Lean controls on ground
    if (inputState.leanFwd) bike.angularVel += 0.03 * dt;
    if (inputState.leanBack) bike.angularVel -= 0.03 * dt;

    // Angle snap to terrain
    const targetAngle = terrainAngle;
    bike.angle += (targetAngle - bike.angle) * 0.18;

    // Check flip on steep downhill
    if (bike.vx > bd.speed * 0.9 && terrainAngle > 0.5) {
      bike.angularVel += 0.02;
    }
  } else {
    bike.onGround = false;
    bike.airTime += dt;
    // Air lean
    if (inputState.leanFwd) bike.angularVel += 0.025 * dt;
    if (inputState.leanBack) bike.angularVel -= 0.025 * dt;
    bike.angularVel *= 0.97;
  }

  // Angular velocity
  bike.angle += bike.angularVel * dt;
  bike.angularVel *= 0.88;

  // Crash if too tilted
  if (bike.onGround && (bike.angle > 1.1 || bike.angle < -1.1)) {
    bike.crashed = true; showLose('Flipped over!'); return;
  }

  // Move
  bike.x += bike.vx * dt;
  bike.y += bike.vy * dt;

  // Fell off world
  if (bike.y > canvas.height + 100) { bike.crashed = true; showLose('Fell off the mountain!'); return; }
  if (bike.x < 0) bike.x = 0;

  // Collectibles
  for (const c of level.collectibles) {
    if (!c.collected) {
      const dx = bike.x - c.x, dy = bike.y - c.y;
      if (Math.sqrt(dx*dx+dy*dy) < 28) {
        c.collected = true;
        if (c.type === 'star') { score += 50; spawnParticles(c.x, c.y, '#ffd700', 12); }
        else { score += 10; spawnParticles(c.x, c.y, '#ffa500', 8); }
      }
    }
  }
  // Fuel cans
  for (const f of level.fuelCans) {
    if (!f.collected) {
      const dx = bike.x - f.x, dy = bike.y - f.y;
      if (Math.sqrt(dx*dx+dy*dy) < 30) {
        f.collected = true;
        fuel = Math.min(100, fuel + 35);
        spawnParticles(f.x, f.y, '#00e676', 10);
      }
    }
  }

  // Trail
  bike.trailPoints.push({ x: bike.x, y: bike.y });
  if (bike.trailPoints.length > 30) bike.trailPoints.shift();

  // Particles when gas
  if (inputState.gas && bike.onGround && Math.random() < 0.3) {
    spawnParticles(bike.x - 20, bike.y + 10, onMud ? '#8d6e63' : '#888', 3);
  }

  // Check win
  if (bike.x >= level.finishX - 30) {
    showWin();
  }

  // Score from speed
  if (bike.onGround && bike.vx > 0.5) score += Math.floor(bike.vx * 0.3);

  // Camera
  camera.x = Math.max(0, bike.x - canvas.width * 0.35);

  // Update HUD
  document.getElementById('hud-score').textContent = score;
  const fw = (fuel / 100 * 100).toFixed(0);
  document.getElementById('fuel-bar').style.width = fw + '%';
}

// ── PARTICLES ──────────────────────────────────────────────
function spawnParticles(x, y, color, count) {
  for (let i = 0; i < count; i++) {
    particles.push({
      x, y,
      vx: (Math.random()-0.5) * 4,
      vy: -Math.random() * 3 - 1,
      life: 1.0, color,
      size: 3 + Math.random() * 4
    });
  }
}

function updateParticles(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x += p.vx * dt; p.y += p.vy * dt;
    p.vy += 0.1 * dt;
    p.life -= 0.04 * dt;
    if (p.life <= 0) particles.splice(i, 1);
  }
}

// ── RENDERER ──────────────────────────────────────────────
const COLORS = {
  sky1_forest: '#1a237e', sky2_forest: '#283593',
  sky1_volcano: '#3e0000', sky2_volcano: '#7b0000',
  ground_forest: '#2e7d32', ground_volcano: '#4a0d0d',
  terrain_forest: ['#4caf50','#388e3c','#2e7d32','#1b5e20'],
  terrain_volcano: ['#b71c1c','#880e0e','#621010','#4a0d0d']
};

function drawBackground(isVolcano) {
  const c1 = isVolcano ? COLORS.sky1_volcano : COLORS.sky1_forest;
  const c2 = isVolcano ? COLORS.sky2_volcano : COLORS.sky2_forest;
  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0, c1);
  grad.addColorStop(1, c2);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Stars/embers
  ctx.save();
  const t = Date.now() / 1000;
  for (let i = 0; i < 40; i++) {
    const sx = ((i * 137.5 + camera.x * 0.05) % canvas.width + canvas.width) % canvas.width;
    const sy = 20 + (i * 53) % (canvas.height * 0.45);
    const sz = 1 + (i % 3) * 0.5;
    ctx.globalAlpha = 0.4 + Math.sin(t + i) * 0.3;
    ctx.fillStyle = isVolcano ? '#ff6600' : '#ffffff';
    ctx.fillRect(sx, sy, sz, sz);
  }
  ctx.globalAlpha = 1;
  ctx.restore();

  // Background mountains (parallax)
  drawMountainSilhouettes(isVolcano);
}

function drawMountainSilhouettes(isVolcano) {
  const color = isVolcano ? 'rgba(80,10,10,0.6)' : 'rgba(20,40,80,0.5)';
  ctx.fillStyle = color;
  const camOff = camera.x * 0.15;
  ctx.beginPath();
  ctx.moveTo(0, canvas.height);
  for (let x = 0; x <= canvas.width; x += 40) {
    const mx = x + camOff;
    const my = canvas.height * 0.35 + Math.sin(mx * 0.008) * 80 + Math.cos(mx * 0.02) * 40;
    ctx.lineTo(x, my);
  }
  ctx.lineTo(canvas.width, canvas.height);
  ctx.closePath();
  ctx.fill();

  const color2 = isVolcano ? 'rgba(100,20,20,0.5)' : 'rgba(30,60,110,0.45)';
  ctx.fillStyle = color2;
  const camOff2 = camera.x * 0.25;
  ctx.beginPath();
  ctx.moveTo(0, canvas.height);
  for (let x = 0; x <= canvas.width; x += 30) {
    const mx = x + camOff2;
    const my = canvas.height * 0.45 + Math.sin(mx * 0.012 + 1) * 60 + Math.cos(mx * 0.03 + 2) * 30;
    ctx.lineTo(x, my);
  }
  ctx.lineTo(canvas.width, canvas.height);
  ctx.closePath();
  ctx.fill();
}

function drawTerrain(lvl) {
  const isVolcano = lvl.isVolcano;
  const colors = isVolcano ? COLORS.terrain_volcano : COLORS.terrain_forest;
  const pts = lvl.points;
  const camX = camera.x;

  // Find visible range
  const startIdx = Math.max(0, Math.floor(camX / lvl.seg) - 2);
  const endIdx = Math.min(pts.length - 1, startIdx + Math.ceil(canvas.width / lvl.seg) + 4);

  // Ground fill (layered)
  for (let layer = 3; layer >= 0; layer--) {
    ctx.beginPath();
    ctx.moveTo(pts[startIdx].x - camX, canvas.height + 100);
    for (let i = startIdx; i <= endIdx; i++) {
      ctx.lineTo(pts[i].x - camX, pts[i].y + layer * 18);
    }
    ctx.lineTo(pts[endIdx].x - camX, canvas.height + 100);
    ctx.closePath();
    ctx.fillStyle = colors[layer];
    ctx.fill();
  }

  // Surface line
  ctx.beginPath();
  ctx.moveTo(pts[startIdx].x - camX, pts[startIdx].y);
  for (let i = startIdx + 1; i <= endIdx; i++) {
    ctx.lineTo(pts[i].x - camX, pts[i].y);
  }
  ctx.strokeStyle = isVolcano ? '#ff3d00' : '#81c784';
  ctx.lineWidth = 3;
  ctx.stroke();

  // Grass tufts / lava cracks
  if (!isVolcano) {
    ctx.fillStyle = '#a5d6a7';
    for (let i = startIdx; i < endIdx; i += 3) {
      if (Math.abs((pts[i].y - pts[Math.max(0,i-1)].y)) < 10) {
        const gx = pts[i].x - camX;
        const gy = pts[i].y;
        ctx.fillRect(gx - 2, gy - 6, 2, 6);
        ctx.fillRect(gx + 4, gy - 8, 2, 8);
        ctx.fillRect(gx + 10, gy - 5, 2, 5);
      }
    }
  } else {
    ctx.strokeStyle = 'rgba(255,100,0,0.4)';
    ctx.lineWidth = 1;
    for (let i = startIdx; i < endIdx; i += 5) {
      const gx = pts[i].x - camX;
      const gy = pts[i].y + 5;
      ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(gx + 8, gy + 8); ctx.stroke();
    }
  }
}

function drawObstacles(lvl) {
  const camX = camera.x;
  for (const obs of lvl.obstacles) {
    const sx = obs.x - camX;
    if (sx < -80 || sx > canvas.width + 80) continue;
    const sy = obs.y;
    const t = Date.now() / 1000;

    ctx.save();
    ctx.translate(sx, sy);

    switch(obs.type) {
      case 'mud':
        ctx.fillStyle = 'rgba(101,67,33,0.85)';
        ctx.beginPath(); ctx.ellipse(0, 5, 40, 14, 0, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#795548';
        ctx.beginPath(); ctx.ellipse(0, 4, 35, 10, 0, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.15)';
        ctx.beginPath(); ctx.ellipse(-5, 2, 10, 5, -0.3, 0, Math.PI*2); ctx.fill();
        break;
      case 'rock':
        ctx.fillStyle = '#616161';
        ctx.beginPath(); ctx.ellipse(0, -8, 18, 14, 0, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#757575';
        ctx.beginPath(); ctx.ellipse(-4, -12, 10, 8, -0.3, 0, Math.PI*2); ctx.fill();
        break;
      case 'bigrock':
        ctx.fillStyle = '#455a64';
        ctx.beginPath(); ctx.ellipse(0, -15, 28, 22, 0, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#546e7a';
        ctx.beginPath(); ctx.ellipse(-6, -22, 16, 12, -0.3, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#607d8b';
        ctx.beginPath(); ctx.ellipse(-2, -26, 8, 6, -0.3, 0, Math.PI*2); ctx.fill();
        break;
      case 'boulder':
        ctx.fillStyle = '#37474f';
        ctx.beginPath(); ctx.ellipse(0, -22, 35, 28, 0, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#455a64';
        ctx.beginPath(); ctx.ellipse(-8, -32, 18, 14, -0.3, 0, Math.PI*2); ctx.fill();
        break;
      case 'hole':
        ctx.fillStyle = 'rgba(0,0,0,0.9)';
        ctx.beginPath(); ctx.ellipse(0, 5, 28, 10, 0, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#1a1a1a';
        ctx.beginPath(); ctx.ellipse(0, 5, 22, 7, 0, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(0, 5, 28, 10, 0, 0, Math.PI*2); ctx.stroke();
        break;
      case 'deephole':
        ctx.fillStyle = 'rgba(0,0,0,0.98)';
        ctx.beginPath(); ctx.ellipse(0, 5, 38, 14, 0, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#ff0000'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(0, 5, 38, 14, 0, 0, Math.PI*2); ctx.stroke();
        break;
      case 'log':
        ctx.fillStyle = '#795548';
        ctx.save(); ctx.rotate(-0.1);
        ctx.fillRect(-25, -10, 50, 16);
        ctx.fillStyle = '#8d6e63';
        ctx.fillRect(-25, -10, 50, 4);
        ctx.restore();
        break;
      case 'spike':
        ctx.fillStyle = '#b71c1c';
        for (let s = -2; s <= 2; s++) {
          ctx.beginPath();
          ctx.moveTo(s*14, 5);
          ctx.lineTo(s*14 - 7, 5);
          ctx.lineTo(s*14, -25);
          ctx.closePath(); ctx.fill();
        }
        break;
      case 'lavapool':
        const lavaGrad = ctx.createRadialGradient(0, 0, 5, 0, 5, 45);
        lavaGrad.addColorStop(0, '#ff6d00');
        lavaGrad.addColorStop(0.5, '#dd2c00');
        lavaGrad.addColorStop(1, '#8b0000');
        ctx.fillStyle = lavaGrad;
        ctx.beginPath(); ctx.ellipse(0, 5, 45, 15, 0, 0, Math.PI*2); ctx.fill();
        // Bubble animation
        for (let b = 0; b < 3; b++) {
          const bx = Math.sin(t*2 + b*2.1) * 15;
          const by = Math.cos(t*1.7 + b*1.5) * 5;
          ctx.fillStyle = 'rgba(255,150,0,0.6)';
          ctx.beginPath(); ctx.arc(bx, by, 3 + Math.sin(t*3+b)*2, 0, Math.PI*2); ctx.fill();
        }
        break;
      case 'gap':
        ctx.fillStyle = 'rgba(0,0,0,0.95)';
        ctx.fillRect(-45, -5, 90, 60);
        ctx.fillStyle = '#111';
        ctx.fillRect(-40, 0, 80, 55);
        break;
    }
    ctx.restore();
  }
}

function drawCollectibles(lvl) {
  const camX = camera.x;
  const t = Date.now() / 1000;
  for (const c of lvl.collectibles) {
    if (c.collected) continue;
    const sx = c.x - camX;
    if (sx < -30 || sx > canvas.width + 30) continue;
    ctx.save();
    ctx.translate(sx, c.y + Math.sin(t * 2 + c.x) * 4);
    if (c.type === 'star') {
      ctx.font = '22px serif'; ctx.textAlign = 'center';
      ctx.fillStyle = '#ffd700';
      ctx.shadowColor = '#ffd700'; ctx.shadowBlur = 10;
      ctx.fillText('⭐', 0, 6);
    } else {
      ctx.fillStyle = '#ffa500';
      ctx.shadowColor = '#ffa500'; ctx.shadowBlur = 8;
      ctx.beginPath(); ctx.arc(0, 0, 9, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#ffcc02';
      ctx.beginPath(); ctx.arc(-2, -2, 5, 0, Math.PI*2); ctx.fill();
    }
    ctx.shadowBlur = 0;
    ctx.restore();
  }
  // Fuel cans
  for (const f of lvl.fuelCans) {
    if (f.collected) continue;
    const sx = f.x - camX;
    if (sx < -30 || sx > canvas.width + 30) continue;
    ctx.save();
    ctx.translate(sx, f.y + Math.sin(t * 1.5 + f.x) * 3);
    ctx.fillStyle = '#00c853';
    ctx.fillRect(-8, -14, 16, 22);
    ctx.fillStyle = '#b9f6ca';
    ctx.fillRect(-5, -14, 8, 5);
    ctx.fillStyle = '#69f0ae';
    ctx.font = '10px sans-serif'; ctx.textAlign = 'center';
    ctx.fillText('⛽', 0, 5);
    ctx.restore();
  }
}

function drawFinishLine(lvl) {
  const sx = lvl.finishX - camera.x;
  const sy = lvl.finishY;
  if (sx < -50 || sx > canvas.width + 50) return;

  // Pole
  ctx.fillStyle = '#fff';
  ctx.fillRect(sx - 3, sy - 80, 6, 80);
  // Flag
  ctx.fillStyle = '#f44336';
  ctx.fillRect(sx + 3, sy - 80, 30, 20);
  ctx.fillStyle = '#fff';
  for (let i = 0; i < 3; i++) {
    ctx.fillRect(sx + 3 + i*10, sy - 80, 5, 20);
  }
  // Checkered pattern
  ctx.fillStyle = 'rgba(0,0,0,0.8)';
  for (let i = 0; i < 2; i++) {
    ctx.fillRect(sx + 3 + i*20, sy - 70, 10, 10);
    ctx.fillRect(sx + 13 + i*20, sy - 80, 10, 10);
  }
  // Glow
  ctx.save();
  ctx.globalAlpha = 0.2 + Math.sin(Date.now() / 300) * 0.1;
  ctx.fillStyle = '#ffd700';
  ctx.beginPath(); ctx.arc(sx, sy - 40, 30, 0, Math.PI*2); ctx.fill();
  ctx.restore();
}

function drawBike() {
  const bd = bike.data;
  const sx = bike.x - camera.x;
  const sy = bike.y;

  ctx.save();
  ctx.translate(sx, sy);
  ctx.rotate(bike.angle);

  // Shadow
  ctx.save();
  ctx.translate(0, bike.wheelRadius + 6);
  ctx.scale(1, 0.3);
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath(); ctx.ellipse(0, 0, 30, 10, 0, 0, Math.PI*2); ctx.fill();
  ctx.restore();

  // Wheels
  const wr = bike.wheelRadius;
  const wRot = (bike.x / wr) % (Math.PI * 2);

  // Rear wheel
  ctx.save(); ctx.translate(-22, wr);
  ctx.beginPath(); ctx.arc(0, 0, wr, 0, Math.PI*2);
  ctx.fillStyle = '#1a1a1a'; ctx.fill();
  ctx.strokeStyle = bd.color; ctx.lineWidth = 3; ctx.stroke();
  ctx.save(); ctx.rotate(wRot);
  ctx.strokeStyle = '#555'; ctx.lineWidth = 2;
  for (let i = 0; i < 6; i++) {
    ctx.rotate(Math.PI/3);
    ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(0, wr-4); ctx.stroke();
  }
  ctx.restore(); ctx.restore();

  // Front wheel
  ctx.save(); ctx.translate(22, wr);
  ctx.beginPath(); ctx.arc(0, 0, wr, 0, Math.PI*2);
  ctx.fillStyle = '#1a1a1a'; ctx.fill();
  ctx.strokeStyle = bd.color; ctx.lineWidth = 3; ctx.stroke();
  ctx.save(); ctx.rotate(wRot);
  ctx.strokeStyle = '#555'; ctx.lineWidth = 2;
  for (let i = 0; i < 6; i++) {
    ctx.rotate(Math.PI/3);
    ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(0, wr-4); ctx.stroke();
  }
  ctx.restore(); ctx.restore();

  // Frame
  ctx.strokeStyle = bd.color; ctx.lineWidth = 4; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-22, wr); ctx.lineTo(0, -8); ctx.lineTo(22, wr); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(0, wr); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-22, wr); ctx.lineTo(22, wr); ctx.stroke();

  // Fork
  ctx.beginPath(); ctx.moveTo(10, -8); ctx.lineTo(22, wr); ctx.strokeStyle = '#aaa'; ctx.lineWidth = 3; ctx.stroke();

  // Handlebar
  ctx.fillStyle = '#999';
  ctx.fillRect(6, -16, 14, 4);
  ctx.fillStyle = '#555';
  ctx.beginPath(); ctx.arc(6, -14, 4, 0, Math.PI*2); ctx.fill();

  // Seat
  ctx.fillStyle = '#333';
  ctx.beginPath(); ctx.ellipse(-8, -16, 14, 5, -0.2, 0, Math.PI*2); ctx.fill();
  ctx.fillStyle = '#555';
  ctx.beginPath(); ctx.ellipse(-8, -18, 12, 4, -0.2, 0, Math.PI*2); ctx.fill();

  // Rider (emoji style)
  ctx.font = '26px serif'; ctx.textAlign = 'center';
  if (bike.angle > 0.3) ctx.fillText('😱', 0, -28);
  else if (inputState.gas) ctx.fillText('😤', 0, -28);
  else ctx.fillText(bd.emoji.replace(/🚵|🏍️|🛵|🏎️|🚜|🔥|💀|⚡|🤖|🥷/, '🧑'), 0, -28);

  // Exhaust smoke when gas
  if (inputState.gas && bike.onGround) {
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = '#999';
    ctx.beginPath(); ctx.arc(-28 + Math.random()*4, wr - 5, 4 + Math.random()*4, 0, Math.PI*2); ctx.fill();
  }
  ctx.globalAlpha = 1;

  ctx.restore();
}

function drawParticles() {
  for (const p of particles) {
    ctx.globalAlpha = p.life;
    ctx.fillStyle = p.color;
    ctx.beginPath(); ctx.arc(p.x - camera.x, p.y, p.size * p.life, 0, Math.PI*2); ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function drawGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!level) return;
  drawBackground(level.isVolcano);
  drawTerrain(level);
  drawObstacles(level);
  drawCollectibles(level);
  drawFinishLine(level);
  drawBike();
  drawParticles();

  // Speed indicator
  if (bike.vx > 0.5) {
    ctx.fillStyle = `rgba(255,215,0,${Math.min(0.8, bike.vx/8)})`;
    ctx.font = `bold ${12 + Math.floor(bike.vx)}px sans-serif`;
    ctx.textAlign = 'right';
    ctx.fillText(`⚡ ${(bike.vx * 20).toFixed(0)} km/h`, canvas.width - 10, canvas.height - 80);
  }

  // Mud warning
  if (bike.mudSlow > 0) {
    ctx.fillStyle = 'rgba(101,67,33,0.7)';
    ctx.font = 'bold 16px sans-serif'; ctx.textAlign = 'center';
    ctx.fillText('🟫 MUD ZONE!', canvas.width/2, canvas.height - 75);
  }

  // Air combo
  if (bike.airTime > 30) {
    ctx.fillStyle = '#00bcd4';
    ctx.font = 'bold 18px sans-serif'; ctx.textAlign = 'center';
    ctx.fillText('✈️ AIR TIME!', canvas.width/2, 100);
  }
}

// ── GAME LOOP ─────────────────────────────────────────────
let lastTime = 0;
function gameLoop(timestamp) {
  if (!isGameRunning) return;
  const dt = Math.min((timestamp - lastTime) / 16.67, 3);
  lastTime = timestamp;
  updateBike(dt);
  updateParticles(dt);
  drawGame();
  frameId = requestAnimationFrame(gameLoop);
}

// ── GAME CONTROLS ─────────────────────────────────────────
function setGas(v)      { inputState.gas = v;       document.getElementById('btn-gas').classList.toggle('pressed', v); }
function setBrake(v)    { inputState.brake = v;     document.getElementById('btn-brake').classList.toggle('pressed', v); }
function setLeanFwd(v)  { inputState.leanFwd = v;   document.getElementById('btn-lean-fwd').classList.toggle('pressed', v); }
function setLeanBack(v) { inputState.leanBack = v;  document.getElementById('btn-lean-back').classList.toggle('pressed', v); }

// Keyboard
document.addEventListener('keydown', e => {
  if (gameState !== 'playing') return;
  if (e.key==='ArrowRight'||e.key==='d') setGas(true);
  if (e.key==='ArrowLeft' ||e.key==='a') setBrake(true);
  if (e.key==='ArrowUp'   ||e.key==='w') setLeanBack(true);
  if (e.key==='ArrowDown' ||e.key==='s') setLeanFwd(true);
  if (e.key==='Escape') togglePause();
});
document.addEventListener('keyup', e => {
  if (e.key==='ArrowRight'||e.key==='d') setGas(false);
  if (e.key==='ArrowLeft' ||e.key==='a') setBrake(false);
  if (e.key==='ArrowUp'   ||e.key==='w') setLeanBack(false);
  if (e.key==='ArrowDown' ||e.key==='s') setLeanFwd(false);
});

// ── SCREEN MANAGEMENT ─────────────────────────────────────
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  const el = document.getElementById(id);
  if (el) el.classList.remove('hidden');
  gameState = 'menu';
}

function selectMap(mapId) {
  currentMap = mapId;
  if (mapId === 2) {
    // Check if any map1 level completed
    const map1Done = Object.keys(saveData.completedLevels).some(k => k.startsWith('1_'));
    if (!map1Done) {
      alert('🔒 Complete at least 1 level in Forest Peak to unlock Volcano Ridge!');
      return;
    }
  }
  buildLevelSelect(mapId);
  showScreen('level-select');
}

function buildLevelSelect(mapId) {
  const grid = document.getElementById('levels-grid');
  grid.innerHTML = '';
  const title = mapId===1 ? '🌲 FOREST PEAK' : '🌋 VOLCANO RIDGE';
  const sub = mapId===1 ? 'Levels 1–25 | Forest Mountain' : 'Levels 26–50 | Volcanic Mountains';
  document.getElementById('map-title').textContent = title;
  document.getElementById('map-subtitle').textContent = sub;

  const unlocked = saveData.unlockedLevels[mapId] || [1];

  for (let i = 1; i <= 25; i++) {
    const btn = document.createElement('div');
    btn.className = 'level-btn';
    const key = mapId + '_' + i;
    const completed = saveData.completedLevels[key];
    const isUnlocked = unlocked.includes(i) || completed;
    const stars = saveData.levelStars[key] || '';

    if (completed) { btn.classList.add('completed'); }
    else if (isUnlocked) { btn.classList.add('unlocked'); }
    else { btn.classList.add('locked'); }

    const displayNum = mapId === 2 ? i + 25 : i;
    btn.innerHTML = `<div class="level-num">${displayNum}</div><div class="level-stars">${stars || '•••'}</div>`;

    if (isUnlocked) {
      btn.onclick = () => startLevel(mapId, i);
    }
    grid.appendChild(btn);
  }
}

// ── BIKE SELECT UI ────────────────────────────────────────
function buildBikeGrid(containerId) {
  const grid = document.getElementById(containerId);
  grid.innerHTML = '';
  BIKES.forEach((b, i) => {
    const card = document.createElement('div');
    card.className = 'bike-card' + (saveData.unlockedBikes.includes(i) ? '' : ' locked');
    if (i === selectedBike) card.classList.add('selected');
    card.innerHTML = `<div class="bike-emoji">${b.emoji}</div><div class="bike-name">${b.name}</div><div class="bike-stars">${b.stars}</div>`;
    card.onclick = () => {
      if (!saveData.unlockedBikes.includes(i)) {
        alert(`🔒 ${b.name} unlocks after completing level ${b.unlock}!`);
        return;
      }
      document.querySelectorAll('.bike-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      selectedBike = i;
      updateBikeInfo(i);
    };
    grid.appendChild(card);
  });
  updateBikeInfo(selectedBike);
}

function updateBikeInfo(id) {
  const b = BIKES[id];
  document.getElementById('sel-bike-name').textContent = b.emoji + ' ' + b.name;
  document.getElementById('sel-bike-stats').textContent =
    `Speed: ${b.stars}  |  Grip: ${(b.grip*100).toFixed(0)}%  |  Accel: ${(b.accel*100).toFixed(0)}`;
}

function confirmBikeSelect() {
  saveData.selectedBike = selectedBike;
  saveSave();
  showScreen('main-menu');
}

// ── START LEVEL ───────────────────────────────────────────
function startLevel(mapId, levelNum) {
  currentMap = mapId;
  currentLevel = levelNum;
  score = 0;
  fuel = 100;
  gameTime = 0;
  particles = [];

  // Generate level
  level = generateLevel(mapId, levelNum);
  initBike(selectedBike, level);
  camera.x = 0;

  // UI
  showScreen('dummy'); // hide all screens
  document.getElementById('hud').style.display = 'flex';
  document.getElementById('controls').style.display = 'flex';
  document.getElementById('pause-btn').style.display = 'flex';
  document.getElementById('hud-level').textContent = mapId===2 ? levelNum+25 : levelNum;

  // Timer
  if (gameTimerInterval) clearInterval(gameTimerInterval);
  gameTimerInterval = setInterval(() => {
    if (gameState !== 'playing') return;
    gameTime++;
    const m = Math.floor(gameTime/60).toString().padStart(2,'0');
    const s = (gameTime%60).toString().padStart(2,'0');
    document.getElementById('hud-time').textContent = m+':'+s;
    // Time limit
    if (gameTime >= level.timeLimit) {
      bike.crashed = true;
      showLose('⏰ Time ran out!');
    }
    // Unlock bikes
    checkBikeUnlocks();
  }, 1000);

  gameState = 'playing';
  isGameRunning = true;
  lastTime = performance.now();
  if (frameId) cancelAnimationFrame(frameId);
  frameId = requestAnimationFrame(gameLoop);
}

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  const el = document.getElementById(id);
  if (el) el.classList.remove('hidden');
}

function checkBikeUnlocks() {
  const completedCount = Object.keys(saveData.completedLevels).length;
  BIKES.forEach((b, i) => {
    if (!saveData.unlockedBikes.includes(i) && completedCount >= b.unlock) {
      saveData.unlockedBikes.push(i);
    }
  });
}

// ── WIN / LOSE ────────────────────────────────────────────
function showWin() {
  if (gameState === 'win') return;
  gameState = 'win';
  isGameRunning = false;

  const key = currentMap + '_' + currentLevel;
  saveData.completedLevels[key] = true;

  // Stars
  const tf = level.timeLimit;
  let stars = '⭐';
  if (gameTime < tf * 0.5) stars = '⭐⭐⭐';
  else if (gameTime < tf * 0.75) stars = '⭐⭐';
  saveData.levelStars[key] = stars;

  // Bonus score
  const timeBonus = Math.max(0, (level.timeLimit - gameTime) * 5);
  const fuelBonus = Math.floor(fuel * 3);
  score += timeBonus + fuelBonus;

  // Unlock next level
  const nextL = currentLevel + 1;
  if (nextL <= 25) {
    if (!saveData.unlockedLevels[currentMap]) saveData.unlockedLevels[currentMap] = [1];
    if (!saveData.unlockedLevels[currentMap].includes(nextL)) {
      saveData.unlockedLevels[currentMap].push(nextL);
    }
  }
  // Unlock map 2 after level 1 on map 1
  if (currentMap === 1 && currentLevel >= 1) {
    if (!saveData.unlockedLevels[2]) saveData.unlockedLevels[2] = [];
    if (!saveData.unlockedLevels[2].includes(1)) saveData.unlockedLevels[2].push(1);
  }
  saveSave();

  // Show win screen
  document.getElementById('win-stars').textContent = stars;
  document.getElementById('win-stats').innerHTML =
    `Score: <b style="color:#ffd700">${score}</b><br>Time: ${Math.floor(gameTime/60)}:${(gameTime%60).toString().padStart(2,'0')}<br>Time Bonus: +${timeBonus}&nbsp;&nbsp;Fuel Bonus: +${fuelBonus}`;

  const hasNext = currentLevel < 25;
  document.getElementById('next-level-btn').style.display = hasNext ? 'block' : 'none';
  document.getElementById('win-overlay').style.display = 'flex';
}

function showLose(reason) {
  if (gameState === 'lose') return;
  gameState = 'lose';
  isGameRunning = false;
  document.getElementById('lose-title').textContent = reason.startsWith('⏰') ? reason : '💀 ' + reason;
  document.getElementById('lose-stats').innerHTML = `Score: <b style="color:#ffd700">${score}</b><br>Try again to beat this level!`;
  document.getElementById('lose-overlay').style.display = 'flex';
}

function nextLevel() {
  document.getElementById('win-overlay').style.display = 'none';
  const nextL = currentLevel + 1;
  if (nextL <= 25) startLevel(currentMap, nextL);
  else showScreen('level-select');
}

function restartLevel() {
  document.getElementById('win-overlay').style.display = 'none';
  document.getElementById('lose-overlay').style.display = 'none';
  document.getElementById('pause-overlay').style.display = 'none';
  startLevel(currentMap, currentLevel);
}

function quitToMenu() {
  isGameRunning = false;
  if (frameId) cancelAnimationFrame(frameId);
  if (gameTimerInterval) clearInterval(gameTimerInterval);
  document.getElementById('win-overlay').style.display = 'none';
  document.getElementById('lose-overlay').style.display = 'none';
  document.getElementById('pause-overlay').style.display = 'none';
  document.getElementById('hud').style.display = 'none';
  document.getElementById('controls').style.display = 'none';
  document.getElementById('pause-btn').style.display = 'none';
  gameState = 'menu';
  level = null;
  showScreen('main-menu');
}

function togglePause() {
  if (gameState === 'playing') {
    gameState = 'paused';
    isGameRunning = false;
    document.getElementById('pause-overlay').style.display = 'flex';
    document.getElementById('pause-btn').textContent = '▶';
  } else if (gameState === 'paused') {
    gameState = 'playing';
    isGameRunning = true;
    document.getElementById('pause-overlay').style.display = 'none';
    document.getElementById('pause-btn').textContent = '⏸';
    lastTime = performance.now();
    frameId = requestAnimationFrame(gameLoop);
  }
}

function showHelp() {
  alert(
    '🎮 HOW TO PLAY\n\n' +
    '▶ GAS — Accelerate forward\n' +
    '◀ BRAKE — Slow down / reverse\n' +
    '↺ ↻ — Lean back / forward (balance)\n\n' +
    '⭐ Collect coins and stars for bonus score\n' +
    '⛽ Collect fuel cans to refill fuel\n' +
    '🔥 Avoid lava, spikes, deep holes!\n' +
    '🏁 Reach the finish flag to complete the level\n\n' +
    '📱 On keyboard: Arrow Keys / WASD\n' +
    'Esc = Pause'
  );
}

// ── INIT ──────────────────────────────────────────────────
function initGame() {
  loadSave();
  buildBikeGrid('bikes-grid-garage');
  // Update map2 lock
  const map1Done = Object.keys(saveData.completedLevels).some(k => k.startsWith('1_'));
  if (map1Done) {
    const lockEl = document.getElementById('map2-lock');
    if (lockEl) lockEl.style.display = 'none';
  }
  // Loading screen
  setTimeout(() => {
    document.getElementById('loading-screen').style.display = 'none';
    showScreen('main-menu');
  }, 1800);
}

// Prevent context menu on long press
document.addEventListener('contextmenu', e => e.preventDefault());

// Init
initGame();
